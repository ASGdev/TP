#include<stdio.h>
#include"alloc.h"

// VARIABLE GLOBAL DE DEBUT DE CHAINE
fb TETE=NULL;//TRY "fb TETE;"

void mem_init(){
	TETE.size=HEAP_SIZE;
	TETE.next=NULL;
}

// VERIFICATION SUR LA TAILLE RESTANTE 
// retourne 1 si size "loge"
// 0 sinon
int verification (size_t size)
{
	return 1; 
}


void *mem_alloc(size_t size){
	fb CC=TETE; // CELLULE COURANTE
	fb CELLULE=NULL;
	
	// CREATION CELLULE
	CELLULE.next=NULL;

	if ( verification(size) )
	{
		if (TETE == NULL)
		{
			CELLULE.size=HEAP_SIZE-size;
			TETE.next=*CELLULE;
		}
		else
		{	
			while (CC.next != NULL)
			{
				CC = &CC.next; // &CC.next -> STRUCTURE  && CC.next -> ADRESSE
			}
			CELLULE.size=CC.size-size;
			CC.next = *CELLULE; // *CELLULE -> ADRESSSE
		}
	}
	else
	{printf("ERROR[404]:PROBLEME D ALLOCATION MEMOIRE --- TAILLE INSUFFISANTE ---\n");}
}

void mem_free(void *zone, size_t size)
{
	while (CC=CC.next != NULL)
	{
	CC = &CC.next; // &CC.next -> STRUCTURE  && CC.next -> ADRESSE
	}
}


void mem_show(void (*print)(void *zone, size_t size))
{
	fb CC=TETE; // CELLULE COURANTE
	while (CC.next != NULL)
	{
		(*print)(*CC,CC.size);	
		CC = &CC.next; // &CC.next -> STRUCTURE  && CC.next -> ADRESSE		
	}	
}
